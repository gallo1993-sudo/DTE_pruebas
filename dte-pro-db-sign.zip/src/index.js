import express from "express";
import morgan from "morgan";
import helmet from "helmet";
import cors from "cors";
import dotenv from "dotenv";
import dteRoutes from "./routes/dte.js";

dotenv.config();
const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(morgan("dev"));
app.use(helmet());
app.use(cors());

app.get("/health", (req, res) => res.json({ ok: true, env: process.env.NODE_ENV || "dev" }));
app.use("/dte", dteRoutes);

const port = process.env.PORT || 4000;
app.listen(port, () => console.log(`DTE Pro API on :${port}`));
