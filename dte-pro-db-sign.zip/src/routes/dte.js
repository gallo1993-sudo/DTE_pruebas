import { Router } from "express";
import { pool } from "../db/pool.js";
import { signXMLFromP12 } from "../services/signing.js";

const router = Router();

router.post("/emit", async (req, res) => {
  const payload = req.body || {};
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const ins = await client.query(
      `INSERT INTO dtes (emisor, receptor, items, total) VALUES ($1,$2,$3,$4) RETURNING id`,
      [
        payload.emisor || { nit: "0614-010101-001-3", nombre: "Mi Empresa" },
        payload.receptor || { nit: "0614-020202-002-9", nombre: "Cliente" },
        payload.items || [{ descripcion: "Demo", cantidad: 1, precioUnitario: 10 }],
        (payload.items || [{ cantidad:1, precioUnitario:10 }]).reduce((a,b)=>a + b.cantidad*b.precioUnitario, 0)
      ]
    );
    await client.query("COMMIT");
    res.json({ id: ins.rows[0].id, message: "DTE guardado" });
  } catch (e) {
    await client.query("ROLLBACK");
    console.error(e);
    res.status(500).json({ error: "Error guardando DTE" });
  } finally {
    client.release();
  }
});

router.post("/sign", async (req, res) => {
  try {
    const { xml } = req.body || {};
    if (!xml) return res.status(400).json({ error: "Falta 'xml' en el body" });

    const signed = await signXMLFromP12({
      xml,
      p12Path: process.env.CERT_P12_PATH,
      passphrase: process.env.CERT_P12_PASSWORD
    });
    res.type("application/xml").send(signed);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Error firmando XML" });
  }
});

export default router;
