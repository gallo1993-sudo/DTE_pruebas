// Firma XML usando un certificado en formato .p12 (PKCS#12)
// Extrae clave/cert con node-forge y firma con xml-crypto (enveloped signature)
import fs from "fs";
import forge from "node-forge";
import { SignedXml } from "xml-crypto";

export async function signXMLFromP12({ xml, p12Path, passphrase }) {
  if (!p12Path || !passphrase) {
    throw new Error("CERT_P12_PATH y CERT_P12_PASSWORD requeridos en .env");
  }
  const p12Der = fs.readFileSync(p12Path, { encoding: "binary" });
  const p12Asn1 = forge.asn1.fromDer(p12Der);
  const p12 = forge.pkcs12.pkcs12FromAsn1(p12Asn1, passphrase);
  let keyPem, certPem;

  for (const safeContent of p12.safeContents) {
    for (const safeBag of safeContent.safeBags) {
      if (safeBag.type === forge.pki.oids.pkcs8ShroudedKeyBag) {
        const key = forge.pki.privateKeyToPem(safeBag.key);
        keyPem = key;
      }
      if (safeBag.cert) {
        certPem = forge.pki.certificateToPem(safeBag.cert);
      }
    }
  }

  if (!keyPem || !certPem) {
    throw new Error("No se pudo extraer clave o certificado del .p12");
  }

  const sig = new SignedXml();
  sig.addReference("/*", [
    "http://www.w3.org/2000/09/xmldsig#enveloped-signature",
    "http://www.w3.org/2001/10/xml-exc-c14n#"
  ]);
  sig.signingKey = keyPem;
  sig.keyInfoProvider = {
    getKeyInfo() {
      return `<X509Data><X509Certificate>${certPem.replace(/-----BEGIN CERTIFICATE-----|-----END CERTIFICATE-----|\n/g, "")}</X509Certificate></X509Data>`;
    }
  };
  sig.computeSignature(xml);
  return sig.getSignedXml();
}
